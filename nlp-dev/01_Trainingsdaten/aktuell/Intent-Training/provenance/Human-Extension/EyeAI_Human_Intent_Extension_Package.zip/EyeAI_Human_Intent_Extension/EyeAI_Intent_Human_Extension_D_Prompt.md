# Luna-Max Prompt — EyeAI Intent: Human Extension Experiment D

Arbeite ausschließlich am bestehenden EyeAI-Intent-Training und der bereits abgeschlossenen korrigierten A/B/C-Studie.

## Ziel

Führe **einen neuen kontrollierten Zustand D** durch, der ausschließlich den Effekt zusätzlicher echter menschlicher Clean-Formulierungen gegenüber der bereits eingefrorenen **A — Corrected Baseline** misst.

Die vorhandenen A/B/C-Ergebnisse und Artefakte dürfen nicht verändert oder überschrieben werden.

Der neue Faktor lautet:

`D = A + Human Clean Extension`

Nicht:

`D = C + Human`

Der Grund ist wissenschaftliche Isolierbarkeit: A/M1/T1 ist derzeit die stärkste Konfiguration auf dem primären Human Blind Core und A enthält weder die 74 neue Clean-Extension aus B noch die 16 neuen ASR-Samples aus C. Dadurch misst A→D möglichst sauber den Effekt der menschlichen Daten.

---

# 1. Neue Human-Dateien

Übernimm das bereitgestellte Paket in die kanonische Dataset-Struktur, zunächst unter `Intent_Datasets/Neu/`.

Primärer Kandidat:

`eyeai_human_extension_clean.train`

Aktuell vorbereitet: **207** eindeutige Clean-Samples.

Zusätzlich:

- `eyeai_human_extension_manifest.csv`
- `eyeai_human_extension_exclusions.csv`
- `eyeai_human_asr_sources.txt`
- `eyeai_human_asr_sources.gold`
- `README.md`

Die ASR-Source-Dateien werden **in diesem Experiment noch nicht verwendet**.

---

# 2. Finales kanonisches Gate vor Training

Bevor D trainiert wird, prüfe jeden Human-Kandidaten gegen die vollständige kanonische `dataset_registry.json`.

Insbesondere gegen:

- V2 Clean vollständig, inklusive Hard-Negative-Patch
- V2 Vosk vollständig
- `V2_DEV_CORRECTED` mit 659 Samples
- alle CURRENT Validation-Splits
- V2 Challenge 40
- V2 Boundary 9
- Human Blind Core
- ASR Human Blind Core bzw. dessen semantische Quellen
- Blind Hard Clean/ASR
- Semantic-Gap Blind Clean/ASR
- sämtliche anderen locked Evaluation-Splits

Prüfe:

- normalisierte exakte Textüberschneidung
- Text/Label-Duplikate
- Cross-Label-Konflikte
- interne Duplikate

### Harte Regel

**Dev- und Evaluationssplits bleiben unverändert.**

Wenn ein Human-Kandidat mit Dev/Blind/Challenge/Evaluation kollidiert:

→ Human-Kandidat ausschließen.

Nicht den Benchmark verändern.

Wenn ein Human-Kandidat bereits im Training vorhanden ist:

→ nicht erneut hinzufügen.

Erzeuge:

`human_extension_final_gate.csv`
`human_extension_final.train`
`human_extension_final_manifest.json`

Dokumentiere Kandidatenzahl vor und nach dem Gate, Ausschlüsse und Hashes.

---

# 3. Dev-Split unverändert lassen

Verwende exakt denselben eingefrorenen Development-Split wie in A/B/C:

`V2_DEV_CORRECTED`

Erwartet:

- 659 Samples
- SHA-256 `bdb2122acc9c7d8e42e9a84d593ea4162d9688d599c3f0a7eee66ad99f75663f`

Wenn Hash oder Count abweichen:

**FAIL FAST.**

Keine erneute Bereinigung des Dev-Splits aufgrund der Human-Daten.

Stattdessen kollidierende Human-Samples entfernen.

---

# 4. Referenzzustand A nicht neu definieren

Die Referenz bleibt die bereits trainierte:

`A — Corrected Baseline`

mit:

- V2 Clean = 2.918
- V2 Vosk = 1.828
- Dev = 659
- identischen fünf Seeds
- T1/T2
- M0–M3
- eingefrorener Trainingslogik

Die 74 Clean-Samples aus B und die 16 neuen ASR-Samples aus C gehören **nicht** in D.

---

# 5. Zustand D

## M0

`2.918 V2 Clean + Human Clean Extension`

Keine zusätzlichen neuen ASR-Daten.

## M1

Historische V2-Strategie wie A:

- V2 Clean + Human Clean Extension
- bestehende 1.828 Vosk-Samples
- dieselbe deterministische ~60/40-Mixing-/Upsampling-Logik

## M2

M0-D-Clean-Checkpoint → Joint Fine-Tuning mit:

- V2 Clean + Human Clean Extension
- bestehenden 1.828 Vosk-Samples

## M3

M0-D-Clean-Checkpoint → Fine-Tuning ausschließlich auf den bestehenden 1.828 Vosk-Samples.

Wichtig: Die Human-Daten sind in D **Clean-only**. Keine TTS→Vosk-Erweiterung im selben Versuch.

---

# 6. Alles andere konstant halten

Gegenüber A unverändert:

- BaselineCNN-Architektur
- T1 Word Tokenizer
- T2 BPE Tokenizer
- Label-Reihenfolge
- max sequence length
- Preprocessing
- Batch Size
- Optimizer
- Loss
- Lernraten
- max epochs
- Patience
- Early-Stopping-Regel
- Sampling-/Upsampling-Logik
- Shuffle-Logik
- deterministische Operationen

Seeds exakt:

- 20260810
- 20260811
- 20260812
- 20260813
- 20260814

Keine Hyperparameteroptimierung.

---

# 7. Trainiere alle M/T-Kombinationen

Trainiere D für:

- M0/T1
- M0/T2
- M1/T1
- M1/T2
- M2/T1
- M2/T2
- M3/T1
- M3/T2

jeweils fünf Seeds.

Also 40 neue D-Artefakte.

A wird als bereits eingefrorener Comparator verwendet. A nur dann erneut trainieren, wenn eine technische Reproduzierbarkeitsprüfung zeigt, dass die vorhandenen A-Artefakte nicht zur eingefrorenen Protokollversion gehören. In diesem Fall zuerst stoppen und berichten.

---

# 8. Primäre Hypothese und Auswertung

Primärer Vergleich:

`D - A`

Die Hauptfrage lautet:

Verbessern echte menschliche Clean-Formulierungen die Generalisierung gegenüber der korrigierten V2-Baseline?

Primäre Benchmarks:

1. Human Blind Core Clean
2. Human Blind Core ASR

Sekundär:

- Blind Hard Clean
- Blind Hard ASR
- Semantic-Gap Blind Clean
- Semantic-Gap Blind ASR
- V2 Challenge 40
- V2 Boundary 9
- neue Validation-Splits
- Legacy Validation nur als Evaluation

Keine Evaluation zur nachträglichen Änderung von D verwenden.

---

# 9. Besonders relevante Klassen

Berichte D−A per-class F1 mindestens für:

- REDIRECT_TO_LLM
- ABORT
- MEASURE_DISTANCE
- SET_FREQUENCY
- SET_BPS
- CHANGE_SPEECH_SPEED
- CHANGE_SPEAKER
- OBJECT_DETECTION
- TEXT_RECOGNITION
- OPEN_SETTINGS

Besonders prüfen, ob die Human-Daten die in B/C beobachteten Boundary-Probleme entschärfen, ohne andere Klassen zu verschlechtern.

---

# 10. T1 und T2 getrennt

Keine primäre Entscheidung anhand eines T1/T2-Gesamtmittels.

Berichte pro M/T:

- Mean über 5 Seeds
- SD
- Median
- Min/Max
- alle fünf Einzelwerte
- gepaartes Seed-Delta D−A

---

# 11. Keine Gewinnerwahl nur nach einem einzelnen Seed

Primäre Bewertung auf Konfigurationsebene über die fünf Seeds.

Ein einzelnes Deployment-Artefakt darf erst später ausgewählt werden.

---

# 12. Plots

Erzeuge mindestens:

1. A vs D — Human Blind Core Clean Macro-F1
2. A vs D — Human Blind Core ASR Macro-F1
3. D−A pro M/T
4. Per-Class-F1 A vs D
5. Per-Class-Deltas
6. Clean→ASR-Degradation A vs D
7. Seed-Streuung
8. T1 vs T2
9. Boundary-Gruppen
10. Confusion Matrices auf Human Blind Core

PNG + möglichst SVG.

---

# 13. Bericht

Erzeuge:

`HUMAN_EXTENSION_D_PROTOCOL.md`
`HUMAN_EXTENSION_D_RESULTS.md`

Im Resultat mindestens:

- endgültige Human-Samplezahl nach Registry-Gate
- Hash des finalen Human-Trainingsfiles
- A vs D pro M/T
- A vs D pro Klasse
- Clean/ASR
- Seed-Stabilität
- Hard-/Semantic-Gap-Verhalten
- Regressionen
- Ressourcen
- klare Aussage, ob Human Clean Extension insgesamt hilfreich, neutral oder gemischt wirkt

Noch keine App-Integration.

Noch keine ASR-Erzeugung aus den Human-Sätzen.

---

# 14. Wissenschaftliche Regel

Nach dem finalen Human-Gate und dem Schreiben von `HUMAN_EXTENSION_D_PROTOCOL.md`:

**keine Beispiele, Labels, Splits, Hyperparameter oder Auswahlregeln anhand der neuen Ergebnisse verändern.**

Wenn D nicht hilft, wird das Ergebnis akzeptiert und nicht durch nachträgliches Cherry-Picking repariert.

---

# 15. Task-Ende

Der Task endet mit:

- finalem Human-Gate
- 40 D-Artefakten
- identischer Evaluation wie A
- vollständigen A↔D-Deltas
- Plots
- `HUMAN_EXTENSION_D_RESULTS.md`

Danach stoppen. Wir entscheiden anschließend separat, ob ein Experiment `D + Human-ASR`, eine Kombination mit B/C oder die App-Integration sinnvoll ist.
