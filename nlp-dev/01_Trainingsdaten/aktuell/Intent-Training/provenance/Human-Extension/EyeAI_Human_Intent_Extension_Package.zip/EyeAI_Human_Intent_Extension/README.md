# EyeAI Human Intent Extension

## Zweck

Dieses Paket bereitet die drei tatsächlich unterschiedlichen menschlichen Intent-Korpora als **neuen, separaten Clean-Trainingsfaktor** auf.

Es soll im nächsten kontrollierten Versuch als Zustand **D = A + Human Clean Extension** verwendet werden.

Wichtig: Die bestehenden Zustände A/B/C bleiben eingefroren. D baut bewusst auf **A (Corrected Baseline)** auf, nicht auf C, damit der Effekt realer menschlicher Formulierungen isoliert gemessen wird.

## Quellen

Es existieren genau drei unterschiedliche SATZ/SOLL-Korpora:

- Person 1: `M0_T1.txt` — 81 Rohzeilen
- Person 2: `M0_T1(2).txt` — 100 Rohzeilen
- Person 3: `M0_T1(3).txt` — 258 Rohzeilen

Die jeweiligen M0–M3/T1–T2-Auswertungsdateien innerhalb einer Person besitzen dieselbe SATZ/SOLL-Sequenz. Deshalb wurde pro Person eine repräsentative Datei verwendet.

Gesamt: **439 Rohzeilen**.

Nach normalisierter Deduplikation existieren 402 eindeutige Text/Label-Paare und 401 eindeutige normalisierte Texte. Ein normalisierter Text besitzt einen Cross-Label-Konflikt (`Sprachausgabengeschwindigkeit`) und wurde vollständig ausgeschlossen.

## Schutz bestehender Daten

Vor Aufnahme wurden exakte normalisierte Überschneidungen gegen die in diesem Workspace verfügbaren aktiven/geschützten Dateien ausgeschlossen:

- `intent_new_validation.val`
- `intent_semantic_gap.val`
- `intent_recommended_validation.val`
- `intent_blind_core.gold`
- `intent_blind_hard.gold`
- `intent_semantic_gap_blind.gold`
- Legacy `DATASET.val` (Evaluation-only)
- `01_Daten_mit_Widerspruechen_bereinigt_dedupliziert.txt`
- `02_Saubere_Trainingsdaten_bereinigt_dedupliziert.txt`
- `intent_recommended_train_additions.train`

Zusätzlich wurden 41 semantisch problematische/mehrdeutige Kandidaten konservativ ausgeschlossen. Die Entscheidungen stehen vollständig in `eyeai_human_extension_exclusions.csv`.

## Finaler Clean-Pool

**207 neue eindeutige Clean-Trainingsbeispiele**

Klassenverteilung:

label
ABORT                  43
CHANGE_SPEAKER         17
CHANGE_SPEECH_SPEED    19
MEASURE_DISTANCE       23
OBJECT_DETECTION        8
OPEN_SETTINGS          15
REDIRECT_TO_LLM        36
SET_BPS                 8
SET_FREQUENCY           8
TEXT_RECOGNITION       30

Beitrag nach Person (nach allen Filtern, vor endgültigem Repository-Gate):

person
Person_1     54
Person_2     21
Person_3    146

Die natürliche Klassenverteilung wurde **nicht künstlich balanciert** und keine Zeile dupliziert.

## Wichtiger letzter Gate-Schritt

Dieses Paket konnte lokal gegen die oben genannten Dateien geprüft werden. Luna muss vor dem Training zusätzlich gegen die **vollständige kanonische Registry** prüfen, insbesondere:

- `V2_DEV_CORRECTED` (659)
- vollständige V2-Clean-Basis inklusive Hard-Negative-Patch
- vollständige V2-Vosk-Basis
- sämtliche locked Blind-/Challenge-Splits
- sonstige CURRENT-Evaluationsdaten

Wenn dort ein exakter normalisierter Overlap auftaucht, wird **der Human-Kandidat aus D entfernt**. Der eingefrorene Dev-/Blind-Split darf nicht verändert werden.

## Dateien

- `eyeai_human_extension_clean.train` — finaler Clean-Trainingskandidat
- `eyeai_human_extension_manifest.csv` — Provenienz pro Trainingsbeispiel
- `eyeai_human_extension_exclusions.csv` — alle Ausschlüsse und Gründe
- `eyeai_human_asr_sources.txt` / `.gold` — nur für einen späteren separaten ASR-Versuch; im D-Lauf nicht verwenden

## Hashes

- clean train: `3a093db8f5bea068f874c23a333e4315667881183a21d271e1c8590be284de05`
- manifest: `b4229605755db2611c5a1e3162e29ed7c3adbf8f6bac0bf20e090ce68ea9147f`
- exclusions: `02ba5341dc002ab1151cc25cedf5d7d643981a2839c99e65dc905eea27ab76e6`
- ASR sources: `855e992bf7c1757e2664636ec9dde2c40156cb0a27c184bd180065fb9fdc6f1e`
- ASR gold: `3a093db8f5bea068f874c23a333e4315667881183a21d271e1c8590be284de05`

## Experimentregel

Der nächste Versuch soll ausschließlich messen:

`A → D = Effekt zusätzlicher echter menschlicher Clean-Formulierungen`

Nicht gleichzeitig 74 Clean-Extension-Sätze aus B oder 16 neue ASR-Sätze aus C hinzufügen. Interaktionen können später in einem separaten Experiment getestet werden.
